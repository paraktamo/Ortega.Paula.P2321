package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class InventarioDeModificaciones<T extends CSVSerializable & Comparable<T>> implements Serializable, Iterable<T> {

    private List<T> items;
    private static final long serialVersionUID = 1L;

    public InventarioDeModificaciones() {
        this.items = new ArrayList<>();
    }

    public void agregar(T item) {
        if (item == null) {
            throw new NullPointerException("Entrada Invalida");
        }
        items.add(item);
    }

    public T obtenerPorIndice(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Indice Invalido");
        }
        return items.get(indice);
    }

    public boolean eliminarPorIndice(int indice) {
        return items.remove(obtenerPorIndice(indice));
    }

    @Override
    public Iterator<T> iterator() {
        List<T> copia = new ArrayList<>(this.items);
        return copia.iterator();
    }

    public void ordenar() {
        Collections.sort(this.items);
    }

    public void ordenar(Comparator<? super T> c) {
        this.items.sort(c);
        
        /*for (T item: items ){
            System.out.println(item);
        }*/
    }
    
    public boolean estaVacio(){
        return this.items.isEmpty();     
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();

        for (T item : this) {
            if (criterio.test(item)) {
                resultado.add(item);
            }
        }
        return resultado;
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        List<T> copia = new ArrayList<>(this.items);

        for (T item : copia) {
            accion.accept(item);
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {

            if (!estaVacio()) {
                escritor.write(items.get(0).toHeaderCSV());
                escritor.write("\n");
            }

            for (T v : items) {
                escritor.write(v.toCSV());
                escritor.write("\n");
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> funcTextoAObjeto) throws IOException {

        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            this.items.clear();
            
            lector.readLine(); 

            String linea;

            while ((linea = lector.readLine()) != null) {

                this.items.add(funcTextoAObjeto.apply(linea));

            }
        }
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream guardador = new ObjectOutputStream(new FileOutputStream(path))) {
            guardador.writeObject(this.items);

        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        

        try (ObjectInputStream desguardador = new ObjectInputStream(new FileInputStream(path))) {

            this.items = (List<T>) desguardador.readObject();

        }
        
    }

}
