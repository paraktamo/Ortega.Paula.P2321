package model;

import java.io.Serializable;

public interface CSVSerializable extends Serializable {

    public String toCSV();

    public String toHeaderCSV();
}
