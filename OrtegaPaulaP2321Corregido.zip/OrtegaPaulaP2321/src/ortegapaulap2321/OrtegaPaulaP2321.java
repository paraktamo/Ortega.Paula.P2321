package ortegapaulap2321;

import java.io.IOException;
import java.util.Comparator;
import model.InventarioDeModificaciones;
import model.ModificacionDeLorean;
import model.TipoModificacion;

public class OrtegaPaulaP2321 {

    public static void main(String[] args) {
        try {
            InventarioDeModificaciones<ModificacionDeLorean> inv = new InventarioDeModificaciones<>();

            inv.agregar(new ModificacionDeLorean(1, "Flux Capacitor Mk1", "Doc Brown", TipoModificacion.TIEMPO));
            inv.agregar(new ModificacionDeLorean(2, "Mr. Fusion", "Doc Brown", TipoModificacion.ENERGIA));
            inv.agregar(new ModificacionDeLorean(3, "Hover Conversion", "Los Libios", TipoModificacion.CONVERSION_HOVER));
            inv.agregar(new ModificacionDeLorean(4, "Temporal Circuit V3", "Clara Clayton", TipoModificacion.TIEMPO));
            inv.agregar(new ModificacionDeLorean(5, "Shield Upgrade", "Marty McFly", TipoModificacion.SEGURIDAD));

            System.out.println("Modificaciones del DeLorean:");
            inv.paraCadaElemento(System.out::println);

            System.out.println("\nModificaciones tipo TIEMPO:");
            inv.filtrar(p -> p.getTipo() == TipoModificacion.TIEMPO)
                    .forEach(System.out::println);

            System.out.println("\nModificaciones que contienen 'hover':");
            inv.filtrar(p -> p.getNombre().contains("Hover"))
                    .forEach(System.out::println);

            System.out.println("\nModificaciones ordenadas por ID:");
            inv.ordenar(Comparator.comparing(ModificacionDeLorean::getId));
            inv.paraCadaElemento(System.out::println);

            System.out.println("\nModificaciones ordenadas por nombre:");
            inv.ordenar(Comparator.comparing(ModificacionDeLorean::getNombre));
            inv.paraCadaElemento(System.out::println);

            inv.guardarEnArchivo("src/data/modificaciones.dat");

            InventarioDeModificaciones<ModificacionDeLorean> cargado = new InventarioDeModificaciones<>();
            cargado.cargarDesdeArchivo("src/data/modificaciones.dat");

            System.out.println("\nModificaciones cargadas desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);

            inv.guardarEnCSV("src/data/modificaciones.csv");

            cargado.cargarDesdeCSV("src/data/modificaciones.csv", ModificacionDeLorean::fromCSV);

            System.out.println("\nModificaciones cargadas desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
