
package model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;


public class ModificacionDeLorean implements CSVSerializable, Serializable, Comparable<ModificacionDeLorean>{
    private int id;
    private String nombre;
    private String responsable;
    private TipoModificacion tipo;

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getResponsable() {
        return responsable;
    }

    public TipoModificacion getTipo() {
        return tipo;
    }

    public ModificacionDeLorean(int id, String nombre, String responsable, TipoModificacion tipo) {
        this.id = id;
        this.nombre = nombre;
        this.responsable = responsable;
        this.tipo = tipo;
    }
    
    public static ModificacionDeLorean fromCSV(String linea){
        linea = linea.substring(0, linea.length());
        String [] datos = linea.split(",");
        return new ModificacionDeLorean(Integer.parseInt(datos[0]), datos[1], datos[2], TipoModificacion.valueOf(datos[3]) );
    }

    @Override
    public int compareTo(ModificacionDeLorean o) {
       return this.id - o.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ModificacionDeLorean other = (ModificacionDeLorean) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return "ModificacionDeLorean{" + "id=" + id + ", nombre=" + nombre + ", responsable=" + responsable + ", tipo=" + tipo + '}';
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + responsable + "," + tipo;
    }
    
    public static String toHeaderCSV(){
        return  "id,nombre,responsable,tipo";
    }
}
