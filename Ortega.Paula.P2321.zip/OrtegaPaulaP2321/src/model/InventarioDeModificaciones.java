package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CSVSerializable;

/*

Operaciones del inventario

• Persistir binario 
• Persistir CSV 
4. Métodos CSV 
Ejemplo: 
4,Temporal Circuit V3,Clara Clayton,TIEMPO
 */
public class InventarioDeModificaciones<T extends CSVSerializable & Comparable<T>> implements Serializable, Iterable<T> {

    private List<T> items;
    private static final long serialVersionUID = 1L;

    public InventarioDeModificaciones() {
        this.items = new ArrayList<>();
    }

    public void agregar(T item) {
        if (item == null) {
            throw new NullPointerException("Entrada Invalida");
        }
        items.add(item);
    }

    public T obtenerPorIndice(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Indice Invalido");
        }
        return items.get(indice);
    }

    public boolean eliminarPorIndice(int indice) {
        return items.remove(obtenerPorIndice(indice));
    }

    @Override
    public Iterator<T> iterator() {
        List<T> copia = new ArrayList<>(this.items);
        return copia.iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comp) {
        List<T> copia = new ArrayList<>(this.items);
        return copia.iterator();
    }

    public void ordenar() {
        Collections.sort(this.items);
    }

    public void ordenar(Comparator<? super T> c) {
        this.items.sort(c);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();

        for (T item : this) {
            if (criterio.test(item)) {
                resultado.add(item);
            }
        }
        return resultado;
    }

   
    public void paraCadaElemento(Consumer<? super T> accion) {
        List<T> copia = new ArrayList<>(this.items);

        for (T item : copia) {
            accion.accept(item);
        }
    }

    /*
    Guardar desde archivo binario 
    Cargar desde archivo binario 
    Guardar en CSV
    Cargar en CSV
     */
    public void guardarEnCSV(String path) throws IOException{
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {

            for (T item : this.items) {
                escritor.write(item.toCSV() + "\n");
            }
        } 
    }

    public List<T> cargarDesdeCSV(String path, Function<String, T> tomoTextoDoyObjeto) throws IOException{
        List<T> toReturn = new ArrayList<>();

        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            lector.readLine();

            while ((linea = lector.readLine()) != null) {
                T item = tomoTextoDoyObjeto.apply(linea);
                toReturn.add(item);
            }

        } 
        return toReturn;
    }
  

    public void guardarEnArchivo(String path) throws IOException{
        try (ObjectOutputStream guardador = new ObjectOutputStream(new FileOutputStream(path))) {
            guardador.writeObject(this.items);

        } 
    }

   
    public List<T> cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        List<T> toReturn = null;

        try (ObjectInputStream desguardador = new ObjectInputStream(new FileInputStream(path))) {

            toReturn = (List<T>) desguardador.readObject();

        } 
        return toReturn;
    }

}
