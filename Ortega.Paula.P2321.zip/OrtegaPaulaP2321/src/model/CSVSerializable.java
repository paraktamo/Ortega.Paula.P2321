
package model;

import java.io.Serializable;

/*CSVSerializable 
Interfaz con: 
• toCSV() 
La clase ModificacionDeLorean debe incluir: 
• static fromCSV(String) 
 */
public interface CSVSerializable <T> extends Serializable{
    public String toCSV();
    

    
}
